package com.cg.payroll.exceptions;

public class AssociateDetailNotFoundException extends Exception{
public AssociateDetailNotFoundException() {
	System.out.println("AssociateId not found");
}
}

package com.cg.payroll.services;
import com.cg.payroll.daoservice.*;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;

public class PayrollServicesImpl implements PayrollServices {
	 AssociateDAOImpl associateDAO = new  AssociateDAOImpl();
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		
		Associate associate = new Associate(yearlyInvestmentUnder8oC,accountNumber, firstName,lastName,department,designation,pancard,emailId,new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
		
		associate = associateDAO.save(associate);
		return  associate.getAssociateId();
	}

	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailNotFoundException {
		
		Associate associate =getAssociateDetails(associateId);
		associate.salary.setHra((associate.salary.getBasicSalary()*30)/100);
		associate.salary.setConveyenceAllowance((associate.salary.getBasicSalary()*30)/100);
		associate.salary.setOtherAllowance((associate.salary.getBasicSalary()*35)/100);
		associate.salary.setPersonalAllowance(associate.salary.getBasicSalary()/5);
		associate.salary.setNetSalary(associate.salary.getBasicSalary()+associate.salary.getConveyenceAllowance()+associate.salary.getCompanyPf()+associate.salary.getEpf()+associate.salary.getHra()+associate.salary.getOtherAllowance()+associate.salary.getPersonalAllowance());

		return associate.salary.getNetSalary();
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotFoundException {
		// TODO Auto-generated method stub
		Associate associate = associateDAO.findOne(associateId);
		
		   return associate;
	}
	

	@Override
	public List<Associate> getAllAssociatesDetails() {
		// TODO Auto-generated method stub
		return associateDAO.findAll();
	}

	@Override
	public boolean findId(int associateId) {
		// TODO Auto-generated method stub
		return false;
	}

}
